// {
//   "options": {
//       "popuate": [
//           {
//               "path": ""
//           }
//       ],
//       "select": [],
//       "pagination": true,
//       "page": 1,
//       "limit": 2,
//       "order": {}
//   },
//   "query": {

//   },
//   "search": {
//       "keys": [""],
//       "value": ""
//   }
// }

const paginate = async (params, Modal) => {
  const pagination = params.options?.pagination;
  const searchKeys = params.search?.keys || [];
  const searchValue = params.search?.value;
  const populate = params.options?.populate;
  const select = params.options?.select;
  let page = 1,
    limit = 2,
    skip = (page - 1) * limit;
  let query = {};

  //Search Query
  if (Array.isArray(searchKeys) && searchValue) {
    query["$or"] = [];
    searchKeys.forEach((element) => {
      query["$or"].push({
        [element]: { $regex: new RegExp(searchValue, "i") },
      });
    });
  }

  //Pegination
  if (pagination) {
    page = params.options.page;
    limit = params.options.limit;
    skip = (page - 1) * limit;
  }

  const docs = await Modal.find(query)
    .select(select)
    .populate(populate)
    .skip(skip)
    .limit(limit);
  return docs;
};

module.exports = paginate;
