const Cart = require("../../models/Cart");

const decreaseQty = async (req, res) => {
  const userId = req.user._id;
  let productId = req.body.productId;

  try {
    let cart = await Cart.findOne({ userId: userId });
    if (!cart)
      return res
        .status(404)
        .send({ status: false, message: "Cart not found for this user" });

    let item = cart.products.findIndex((p) => p.productId == productId);

    if (item > -1) {
      let productItem = cart.products[item];
      if (productItem.qty > 0) {
        productItem.qty -= 1;
        cart.products[item] = productItem;
      } else {
        cart.products.splice(item, 1);
        console.log("Cart product", cart.products);
      }
      cart = await cart.save();
      return res.status(200).send({ status: true, updatedCart: cart });
    }
    res
      .status(400)
      .send({ status: false, message: "Item does not exist in cart" });
  } catch (error) {
    console.log("error", error);
    res.status(500).send("Something went wrong");
  }
};

module.exports = decreaseQty;
