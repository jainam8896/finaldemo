const Cart = require("../../models/Cart");
const Product = require("../../models/Product");

const addItemToCart = async (req, res) => {
  const { productId, qty} = req.body;
  const userId = req.user._id;
  const ProductDetails = await Product.findById(productId);
  try {
    let cart = await Cart.findOne({ userId });
    if (cart) {
      let item = cart.products.findIndex((p) => p.productId == productId);
      if (item > -1) {
        let product = cart.products[item];
        if (qty > 0) {
          product.qty = qty;
          cart.products[item] = product;
        } else {
          cart.products.splice(item, 1);
          console.log("Cart product", cart.products);
        }
      } else {
        if (qty > 0) {
          cart.products.push({
            productId,
            qty,
            price: ProductDetails.price,
            total: ProductDetails.price * qty,
          });
          cart.subTotal = cart.products
            .map((products) => products.total)
            .reduce((total, next) => total + next);
        } else {
          return res
            .status(400)
            .json({ status: "fail", message: "Qty must be greater than 0" });
        }
      }
      cart = await cart.save();
      return res.status(201).send(cart);
    } else {
      const newCart = await Cart.create({
        userId,
        products: [
          {
            productId,
            qty,
            price: ProductDetails.price,
            total: ProductDetails.price * qty,
          },
        ],
        subTotal: ProductDetails.price * qty,
      });
      return res.status(201).send(newCart);
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send("Something went wrong");
  }
};

module.exports = addItemToCart;
