const Category = require("../../models/Category");

//Delete Category
const deletcategory = async (req, res) => {
  try {
    const { id } = req.params;
    const category = await Category.findByIdAndDelete(id);
    if (!category) {
      res.status(404).send({ status: "failed", message: "Category Not Found" });
    }
    res
      .status(200)
      .send({ status: "success", message: "Category Deleted Successfully" });
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = deletcategory;
