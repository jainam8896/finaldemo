const User = require("../../models/User");

const getUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById({ _id: id }).select([
      "name",
      "email",
      "age",
      "address",
      "profileimage"
    ]);
    if (!user) {
      return res.status(404).json("User is not found!");
    }
    res.status(200).json(user);
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = getUser;
