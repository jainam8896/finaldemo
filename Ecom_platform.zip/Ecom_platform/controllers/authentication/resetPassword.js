const User = require("../../models/User");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

const resetPassword = async (req, res) => {
  const token = req.query.token;
  const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
  const { newPassword } = req.body;
  const userData = await User.findById(_id);
  if (!userData) {
    return res.status(400).json("This Link Is not valid");
  }
  const hashPassword = bcrypt.hashSync(newPassword, 10);
  userData.password = hashPassword;
  userData.token = null;
  await userData.save();
  console.log(hashPassword);
  res.status(200).json({ message: "Your Password Updated Successfully" });
};

module.exports = resetPassword;
