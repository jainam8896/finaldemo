const express = require("express");
const router = express.Router();
const addItemToCart = require("../controllers/cart/add");
const getCart = require("../controllers/cart/get");
const removeCart = require("../controllers/cart/delete");
const decreaseQty = require("../controllers/cart/decrease");

router.post("/add", addItemToCart);
router.get("/", getCart);
router.delete("/", removeCart);
router.patch("/", decreaseQty);

module.exports = router;
