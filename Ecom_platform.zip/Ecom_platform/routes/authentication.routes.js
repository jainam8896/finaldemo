const express = require("express");
const router = express.Router();
const rules = require("../utils/validations/user/validation");
const validate = require("../middlewares/validate");
const auth = require("../middlewares/auth");
const userRegistration = require("../controllers/authentication/signup");
const userLogin = require("../controllers/authentication/login");
const changePassword = require("../controllers/authentication/changepassword");
const forgetPassword = require("../controllers/authentication/forgetPassword");
const resetPassword = require("../controllers/authentication/resetPassword");
const upload = require("../helper/userimageupload");

router.post(
  "/signup",
  upload.single("profileimage"),
  validate(rules.registerValidator),
  userRegistration
);

router.post("/login", validate(rules.loginValidator), userLogin);

router.post(
  "/changePassword",
  validate(rules.changePasswordValidator),
  auth,
  changePassword
);

router.post(
  "/forgetpassword",
  validate(rules.forgetPasswordValidator),
  forgetPassword
);

router.get(
  "/resetpassword",
  validate(rules.resetPasswordValidator),
  resetPassword
);

module.exports = router;
