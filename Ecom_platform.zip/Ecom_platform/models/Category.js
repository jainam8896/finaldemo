const mongoose = require("mongoose");
//const autopopulate = require("mongoose-autopopulate");

const schema = new mongoose.Schema(
  {
    name:{
      type: String,
      required: true,
    },
    parentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
       default: null,
      //autopopulate: true,
    },
  },
  {
    timestamps: true,
  }
);

//schema.plugin(autopopulate);

const Category = mongoose.model("Category", schema);
module.exports = Category;
