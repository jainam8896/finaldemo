const mongoose = require("mongoose");
//const autopopulate = require("mongoose-autopopulate");

const scehma = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    qty: {
      type: Number,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      ///autopopulate: true,
    },
  },
  {
    timestamps: true,
  }
);

//scehma.plugin(autopopulate);

const Product = mongoose.model("product", scehma);
module.exports = Product;
