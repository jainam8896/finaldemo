const jwt = require("jsonwebtoken");
const User = require("../models/User");

const userAuth = async (req, res, next) => {
  let token;
  const { authorization } = req.headers;
  if (authorization && authorization.startsWith("Bearer")) {
    try {
      token = authorization.split(" ")[1];
      if (!token) {
        return res
          .status(401)
          .json({ status: "failed", message: "Unauthorized User, No Token" });
      }
      const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
      req.user = await User.findById(_id);
      next();
    } catch (error) {
      console.log(error);
      res.send({ status: "failed", message: "Unauthorized User" });
    }
  }
};
module.exports = userAuth;
